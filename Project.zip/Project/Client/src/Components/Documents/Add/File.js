import React from "react";


const File = props=>{
return(<div>{props.fileName}</div>)
}


export default File;