import React from "react";


const Profile = props => {
    return(
        <div>
            profile
        </div>
    )
}
export default Profile;